# DIU - Practica 3, entregables

## Moodboard (diseño visual + logotipo)

    Este mood board muestra la inspiración visual y el estilo deseado para la marca FiestaX. Incluye ejemplos de imágenes de fiestas, una galaxia, y otras imágenes vibrantes y coloridas. También presenta la paleta de colores con tonos vibrantes como rosa, azul y verde, y muestra las fuentes tipográficas que se usarán (Bebas Neue, Cyrillic Poppins Medium, Open Sans). 
## Landing Page

    Este es un boceto básico de la página de inicio de un sitio web para eventos. Incluye secciones como una galería de imágenes ("IMAGENES DE NUESTRAS FIESTAS"), comentarios de usuarios, información sobre próximos eventos ("PROXIMOS EVENTOS") con botones para interactuar, y un footer. El diseño es bastante minimalista y utiliza un esquema de colores que incluye púrpura y gris.

## Mockup: LAYOUT HI-FI
    Este mockup muestra un diseño de alta fidelidad para una página web de eventos. En este resultado final ya podemos ver el funcionamiento de la galeria de imagenes junto a su animación. Tambien tenemos desarollada la sección de proximos eventos con botones interactivos.
    


## Documentación: Publicación del Case Study


(incluye) Valoración del equipo sobre la realización de esta práctica o los problemas surgidos
 
